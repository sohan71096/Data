package com.cg.eis.service;

public interface EmployeeService
{
	 void employeeInsurance();
}
