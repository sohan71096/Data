package com.cg.eis.service;

import com.cg.eis.exception.EmployeeException;

public class Service implements EmployeeService
{
	private double salary;
	private String designation;
	private String insuranceScheme;
	public double getSalary(int salary) 
	{
		int sal=salary;
		if(sal<3000)
		{
			try {
				throw new EmployeeException("Salary Alert!!!");
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			
		}
		else
		{
			System.out.println("Salary above 3000");
		}
		return salary;
	}
	public void setSalary(int salary) 
	{
		int sal=salary;
		if(sal<3000)
		{
			try {
				throw new EmployeeException("Salary Alert!!!");
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			
		}
		else
		{
			System.out.println("Salary above 3000");
		}
		this.salary = salary;
		
	}
	
	
	public String getDesignation()
	{
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
//	public String getInsuranceScheme() {
//		return insuranceScheme;
//	}
//	public void setInsuranceScheme(String insuranceScheme) {
//		this.insuranceScheme = insuranceScheme;
//	}
//@Override
	public String toString() {
		return "salary=" + salary + ", designation=" + designation;
	}
	public void employeeInsurance()
	{
		if(salary>5000 && salary<20000)// && designation=="Trainee")
		{
			insuranceScheme="Scheme C";
		}
		else if ((salary>=20000 && salary<40000) && designation=="Programmer")
		{

			insuranceScheme="Scheme B";
		}
		else if(salary>=40000 && designation=="Manager")
		{

			insuranceScheme="Scheme A";
		}
		else
		{
			insuranceScheme="No Scheme";
		}
		System.out.println("Insurance Scheme is "+insuranceScheme);
	}
	
}
